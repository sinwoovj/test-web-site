function stateScrollObj(param,obj,btn,interval,speed,viewSize,moreSize,dir,data,auto,hover,method,op1){
	var myVar;



	function myFunction() {

	    myVar = setTimeout(alertFunc, 3000);

	}



	function alertFunc() {

	    alert("Hello!");

	}



	
}