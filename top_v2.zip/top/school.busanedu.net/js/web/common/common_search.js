$(function () {
	// 모바일검색
	$(".commonSearchBtnSearch").click(function () {
		document.searchFrm.submit();
	});
});