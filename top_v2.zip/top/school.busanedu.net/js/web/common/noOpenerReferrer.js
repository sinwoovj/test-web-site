$(function () {
	noOpenerReferrer("Y","Y","");
});